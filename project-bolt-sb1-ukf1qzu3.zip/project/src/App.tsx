import React, { useState } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { Users, Wheat, Store, MapPin, Phone, Mail, Navigation } from 'lucide-react';
import { Login } from './pages/Login';
import { Signup } from './pages/Signup';
import { AuthLayout } from './components/AuthLayout';
import FarmerList from './components/FarmerList';
import Header from './components/Header';
import Hero from './components/Hero';
import NearbyView from './components/NearbyView';

function Dashboard() {
  const [activeTab, setActiveTab] = useState<'farmers' | 'merchants'>('farmers');
  const [view, setView] = useState<'list' | 'nearby'>('list');

  return (
    <div className="min-h-screen bg-green-50">
      <Header activeTab={activeTab} setActiveTab={setActiveTab} />
      <Hero />
      <main className="container mx-auto px-4 py-8">
        <div className="flex justify-end mb-6">
          <div className="inline-flex rounded-lg overflow-hidden">
            <button
              onClick={() => setView('list')}
              className={`px-4 py-2 flex items-center gap-2 ${
                view === 'list'
                  ? 'bg-green-600 text-white'
                  : 'bg-white text-green-600 hover:bg-green-50'
              }`}
            >
              <Users size={20} />
              List View
            </button>
            <button
              onClick={() => setView('nearby')}
              className={`px-4 py-2 flex items-center gap-2 ${
                view === 'nearby'
                  ? 'bg-green-600 text-white'
                  : 'bg-white text-green-600 hover:bg-green-50'
              }`}
            >
              <Navigation size={20} />
              Nearby View
            </button>
          </div>
        </div>

        {view === 'list' ? (
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                <Users className="text-green-600" />
                Active Farmers
              </h2>
              <FarmerList />
            </div>
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                <Store className="text-green-600" />
                Featured Crops
              </h2>
              <div className="space-y-4">
                {[
                  { crop: 'Wheat', location: 'Punjab', price: '₹2000/quintal' },
                  { crop: 'Rice', location: 'Haryana', price: '₹3000/quintal' },
                  { crop: 'Cotton', location: 'Gujarat', price: '₹5000/quintal' },
                ].map((item, index) => (
                  <div key={index} className="border-b pb-4 last:border-0">
                    <div className="flex items-center gap-2">
                      <Wheat className="text-green-600" />
                      <span className="font-semibold">{item.crop}</span>
                    </div>
                    <div className="flex items-center gap-4 mt-2 text-sm text-gray-600">
                      <span className="flex items-center gap-1">
                        <MapPin size={16} />
                        {item.location}
                      </span>
                      <span>{item.price}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <NearbyView activeTab={activeTab} />
        )}
      </main>
    </div>
  );
}

function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<Signup />} />
      <Route
        path="/"
        element={
          <AuthLayout>
            <Dashboard />
          </AuthLayout>
        }
      />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default App;