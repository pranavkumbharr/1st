import React, { useState, useEffect } from 'react';
import { MapPin, Navigation, Search, SortAsc } from 'lucide-react';

interface Location {
  latitude: number;
  longitude: number;
}

interface NearbyViewProps {
  activeTab: 'farmers' | 'merchants';
}

function NearbyView({ activeTab }: NearbyViewProps) {
  const [userLocation, setUserLocation] = useState<Location | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState<'distance' | 'name'>('distance');

  useEffect(() => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          });
          setLoading(false);
        },
        () => {
          setLoading(false);
        }
      );
    } else {
      setLoading(false);
    }
  }, []);

  const nearbyFarmers = [
    {
      name: 'Rajesh Kumar',
      location: 'Amritsar, Punjab',
      distance: '2.5 km',
      distanceValue: 2.5,
      crops: ['Wheat', 'Rice'],
    },
    {
      name: 'Amit Patel',
      location: 'Ahmedabad, Gujarat',
      distance: '3.1 km',
      distanceValue: 3.1,
      crops: ['Cotton', 'Groundnut'],
    },
    {
      name: 'Suresh Singh',
      location: 'Karnal, Haryana',
      distance: '4.2 km',
      distanceValue: 4.2,
      crops: ['Rice', 'Sugarcane'],
    },
    {
      name: 'Pradeep Verma',
      location: 'Ludhiana, Punjab',
      distance: '1.8 km',
      distanceValue: 1.8,
      crops: ['Wheat', 'Maize'],
    },
  ];

  const nearbyMerchants = [
    {
      name: 'Punjab Traders',
      location: 'Amritsar, Punjab',
      distance: '1.8 km',
      distanceValue: 1.8,
      interests: ['Wheat', 'Rice'],
    },
    {
      name: 'Gujarat Agro',
      location: 'Ahmedabad, Gujarat',
      distance: '2.7 km',
      distanceValue: 2.7,
      interests: ['Cotton', 'Oilseeds'],
    },
    {
      name: 'Haryana Exports',
      location: 'Karnal, Haryana',
      distance: '3.5 km',
      distanceValue: 3.5,
      interests: ['Rice', 'Wheat'],
    },
    {
      name: 'Agri Solutions',
      location: 'Ludhiana, Punjab',
      distance: '2.1 km',
      distanceValue: 2.1,
      interests: ['Maize', 'Sugarcane'],
    },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
      </div>
    );
  }

  if (!userLocation && !loading) {
    return (
      <div className="bg-white rounded-lg shadow-lg p-6 text-center">
        <Navigation className="mx-auto text-green-600 mb-4" size={48} />
        <h3 className="text-xl font-semibold mb-2">Location Access Required</h3>
        <p className="text-gray-600">
          Please enable location access to see nearby {activeTab === 'farmers' ? 'farmers' : 'merchants'}
        </p>
      </div>
    );
  }

  let items = activeTab === 'farmers' ? nearbyFarmers : nearbyMerchants;

  // Filter items based on search term
  items = items.filter(item => 
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (activeTab === 'farmers' ? 
      item.crops.some(crop => crop.toLowerCase().includes(searchTerm.toLowerCase())) :
      item.interests.some(interest => interest.toLowerCase().includes(searchTerm.toLowerCase())))
  );

  // Sort items
  items = [...items].sort((a, b) => {
    if (sortBy === 'distance') {
      return a.distanceValue - b.distanceValue;
    }
    return a.name.localeCompare(b.name);
  });

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <Navigation className="text-green-600" />
          Nearby {activeTab === 'farmers' ? 'Farmers' : 'Merchants'}
        </h2>
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <MapPin size={16} />
          Your Location
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
          <input
            type="text"
            placeholder={`Search by name, location, or ${activeTab === 'farmers' ? 'crops' : 'interests'}`}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
          />
        </div>
        <div className="flex items-center gap-2">
          <SortAsc size={20} className="text-gray-600" />
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as 'distance' | 'name')}
            className="border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500"
          >
            <option value="distance">Sort by Distance</option>
            <option value="name">Sort by Name</option>
          </select>
        </div>
      </div>

      {items.length === 0 ? (
        <div className="text-center py-8 text-gray-600">
          No {activeTab === 'farmers' ? 'farmers' : 'merchants'} found matching your search criteria
        </div>
      ) : (
        <div className="grid md:grid-cols-2 gap-4">
          {items.map((item, index) => (
            <div key={index} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-lg font-semibold">{item.name}</h3>
                <span className="text-sm text-green-600 font-medium">{item.distance}</span>
              </div>
              <p className="text-sm text-gray-600 flex items-center gap-1 mb-3">
                <MapPin size={16} />
                {item.location}
              </p>
              <div>
                <p className="text-sm text-gray-600 mb-1">
                  {activeTab === 'farmers' ? 'Crops:' : 'Interested in:'}
                </p>
                <div className="flex flex-wrap gap-2">
                  {(activeTab === 'farmers' ? item.crops : item.interests).map((crop, cropIndex) => (
                    <span
                      key={cropIndex}
                      className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded"
                    >
                      {crop}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default NearbyView;