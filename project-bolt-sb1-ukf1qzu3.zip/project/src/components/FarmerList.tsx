import React from 'react';
import { MapPin, Phone, Mail } from 'lucide-react';

function FarmerList() {
  const farmers = [
    {
      name: 'Rajesh Kumar',
      location: 'Amritsar, Punjab',
      crops: ['Wheat', 'Rice'],
      phone: '+91 98765 43210',
      email: 'rajesh@farmconnect.com',
    },
    {
      name: 'Amit Patel',
      location: 'Ahmedabad, Gujarat',
      crops: ['Cotton', 'Groundnut'],
      phone: '+91 98765 43211',
      email: 'amit@farmconnect.com',
    },
    {
      name: 'Suresh Singh',
      location: 'Karnal, Haryana',
      crops: ['Rice', 'Sugarcane'],
      phone: '+91 98765 43212',
      email: 'suresh@farmconnect.com',
    },
  ];

  return (
    <div className="space-y-4">
      {farmers.map((farmer, index) => (
        <div key={index} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
          <h3 className="text-lg font-semibold">{farmer.name}</h3>
          <div className="mt-2 space-y-2 text-sm text-gray-600">
            <p className="flex items-center gap-2">
              <MapPin size={16} />
              {farmer.location}
            </p>
            <p className="flex items-center gap-2">
              <Phone size={16} />
              {farmer.phone}
            </p>
            <p className="flex items-center gap-2">
              <Mail size={16} />
              {farmer.email}
            </p>
          </div>
          <div className="mt-2">
            <p className="text-sm text-gray-600">Crops:</p>
            <div className="flex gap-2 mt-1">
              {farmer.crops.map((crop, cropIndex) => (
                <span
                  key={cropIndex}
                  className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded"
                >
                  {crop}
                </span>
              ))}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

export default FarmerList