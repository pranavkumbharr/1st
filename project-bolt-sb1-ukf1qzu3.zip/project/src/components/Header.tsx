import React from 'react';
import { Sprout } from 'lucide-react';

interface HeaderProps {
  activeTab: 'farmers' | 'merchants';
  setActiveTab: (tab: 'farmers' | 'merchants') => void;
}

function Header({ activeTab, setActiveTab }: HeaderProps) {
  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <Sprout className="text-green-600" size={32} />
            <span className="text-xl font-bold text-green-800">FarmConnect</span>
          </div>
          <nav className="flex space-x-4">
            <button
              onClick={() => setActiveTab('farmers')}
              className={`px-4 py-2 rounded-md transition-colors ${
                activeTab === 'farmers'
                  ? 'bg-green-600 text-white'
                  : 'text-green-600 hover:bg-green-50'
              }`}
            >
              For Farmers
            </button>
            <button
              onClick={() => setActiveTab('merchants')}
              className={`px-4 py-2 rounded-md transition-colors ${
                activeTab === 'merchants'
                  ? 'bg-green-600 text-white'
                  : 'text-green-600 hover:bg-green-50'
              }`}
            >
              For Merchants
            </button>
          </nav>
        </div>
      </div>
    </header>
  );
}

export default Header